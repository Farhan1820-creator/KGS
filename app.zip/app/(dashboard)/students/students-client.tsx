"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { PageToolbar, FilterConfig } from "@/components/layout/page-toolbar";
import { DataTable } from "@/components/layout/data-table";
import { getStudentColumns, StudentRow } from "./student-columns";
import { StudentDialog } from "./student-dialog";

interface StudentsClientProps {
  initialData: StudentRow[];
  classes: { id: number; name: string }[];
  feeStructures: { classId: number; amount: number }[];
  currentMonth: string;
}

export function StudentsClient({ initialData, classes, feeStructures, currentMonth }: StudentsClientProps) {
  const router = useRouter();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogMode, setDialogMode] = useState<"view" | "edit">("view");
  const [dialogTarget, setDialogTarget] = useState<StudentRow | null>(null);
  const [filters, setFilters] = useState<Record<string, string>>({});

  const filterConfig: FilterConfig[] = [
    { type: "search", key: "name", placeholder: "Search by name" },
    { type: "search", key: "contactNumber", placeholder: "Search by contact" },
    {
      type: "select",
      key: "className",
      placeholder: "Filter by class",
      options: classes.map((c) => ({ label: c.name, value: c.name })),
    },
  ];

  const filteredData = useMemo(() => {
    return initialData.filter((row) =>
      Object.entries(filters).every(([key, value]) => {
        if (!value) return true;
        const cell = String(row[key as keyof StudentRow] ?? "").toLowerCase();
        return cell.includes(value.toLowerCase());
      })
    );
  }, [initialData, filters]);

  function handleAdd() {
    setDialogTarget(null);
    setDialogOpen(true);
  }

  // Row click opens the read-only view, which has its own Edit button to
  // switch the same dialog into edit mode.
  function handleView(row: StudentRow) {
    setDialogTarget(row);
    setDialogMode("view");
    setDialogOpen(true);
  }

  // Jumps to the fees page pre-filtered to this student, with the month
  // filter set to the current month so the fee detail is right there.
  function handleViewFeeDetails(row: StudentRow) {
    const params = new URLSearchParams({ studentId: String(row.id), from: currentMonth, to: currentMonth });
    router.push(`/accounts/fees?${params.toString()}`);
  }

  const columns = getStudentColumns({ onViewFeeDetails: handleViewFeeDetails });

  return (
    <div className="page-shell space-y-4">
      <PageToolbar
        filters={filterConfig}
        values={filters}
        onChange={(key, value) => setFilters((f) => ({ ...f, [key]: value }))}
        onAdd={handleAdd}
        addLabel="Add Student"
      />

      <DataTable columns={columns} data={filteredData} onRowClick={handleView} />

      <StudentDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        classes={classes}
        feeStructures={feeStructures}
        student={dialogTarget}
        mode={dialogMode}
        onSaved={() => router.refresh()}
      />
    </div>
  );
}
