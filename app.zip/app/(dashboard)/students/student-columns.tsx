"use client";

import { ColumnDef } from "@tanstack/react-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export type StudentRow = {
  id: number;
  name: string;
  email: string;
  contactNumber: string | null;
  classId: number | null;
  className: string | null;
  rollNumber: string | null;
  fee: number | null; // this student's own fee override, if any
  admissionDate: string | null;
  photoUrl: string | null;
  // overall status across every month from admission date to now — "paid" only
  // if all months are settled, "unpaid" if none are, "pending" if mixed.
  // null = no admission date on file, so the range can't be determined.
  feeStatus: "paid" | "unpaid" | "pending" | null;
};

interface StudentColumnsOptions {
  onViewFeeDetails: (row: StudentRow) => void;
}

export function getStudentColumns({ onViewFeeDetails }: StudentColumnsOptions): ColumnDef<StudentRow>[] {
  return [
    {
      id: "photo",
      header: "",
      cell: ({ row }) =>
        row.original.photoUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={row.original.photoUrl}
            alt={row.original.name}
            className="h-8 w-8 rounded-full object-cover border"
          />
        ) : (
          <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center text-[10px] text-muted-foreground border">
            {row.original.name.slice(0, 1).toUpperCase()}
          </div>
        ),
    },
    { accessorKey: "name", header: "Name" },
    { accessorKey: "email", header: "Email" },
    { accessorKey: "contactNumber", header: "Contact" },
    { accessorKey: "className", header: "Class" },
    { accessorKey: "rollNumber", header: "Roll No." },
    { accessorKey: "admissionDate", header: "Admission Date", cell: ({ row }) => row.original.admissionDate ?? "—" },
    {
      accessorKey: "feeStatus",
      header: "Fee Status",
      cell: ({ row }) => {
        const status = row.original.feeStatus;
        const badgeClass =
          status === "paid"
            ? "bg-green-600 hover:bg-green-600 text-white"
            : status === "pending"
              ? "bg-yellow-500 hover:bg-yellow-500 text-white"
              : "bg-red-600 hover:bg-red-600 text-white";
        const label = status === "paid" ? "Paid" : status === "pending" ? "Pending" : "Unpaid";
        return (
          <div className="flex flex-col items-start gap-1">
            {status ? (
              <Badge className={badgeClass}>{label}</Badge>
            ) : (
              <span className="text-xs text-muted-foreground">Not generated</span>
            )}
            <Button
              size="sm"
              variant="link"
              className="h-auto p-0 text-xs"
              onClick={(e) => {
                e.stopPropagation();
                onViewFeeDetails(row.original);
              }}
            >
              Details
            </Button>
          </div>
        );
      },
    },
  ];
}