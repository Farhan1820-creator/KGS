"use client";

import { ColumnDef } from "@tanstack/react-table";

export type TeacherRow = {
  id: number;
  name: string;
  email: string;
  contactNumber: string | null;
  subjectId: number | null;
  subjectName: string | null;
  teacherId: string | null;
  joinDate: string | null;
};

export function getTeacherColumns(): ColumnDef<TeacherRow>[] {
  return [
    { accessorKey: "teacherId", header: "Teacher ID" },
    { accessorKey: "name", header: "Name" },
    { accessorKey: "email", header: "Email" },
    { accessorKey: "contactNumber", header: "Contact" },
    { accessorKey: "subjectName", header: "Subject" },
    { accessorKey: "joinDate", header: "Join Date", cell: ({ row }) => row.original.joinDate ?? "—" },
  ];
}
