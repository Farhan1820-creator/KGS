"use server";

import { db } from "@/db";
import { users, teachers } from "@/db/schema";
import { teacherSchema } from "./teacher-validation";
import { hash } from "bcryptjs";
import { revalidatePath } from "next/cache";

export async function createTeacher(formData: unknown) {
  const parsed = teacherSchema.safeParse(formData);
  if (!parsed.success) {
    return { success: false, errors: parsed.error.flatten().fieldErrors };
  }

  const { name, email, password, contactNumber, subjectId } = parsed.data;

  try {
    const hashed = await hash(password, 10);

    // single transaction: avoids orphaned user row if teacher insert fails
    await db.transaction(async (tx) => {
      const [user] = await tx
        .insert(users)
        .values({ name, email, password: hashed, contactNumber, role: "teacher" })
        .returning({ id: users.id });

      await tx.insert(teachers).values({
        userId: user.id,
        subjectId: Number(subjectId),
      });
    });

    revalidatePath("/teachers");
    return { success: true };
  } catch (err: any) {
    console.error("createTeacher failed:", err);
    if (err?.code === "23505") {
      return { success: false, errors: { email: ["Email already in use"] } };
    }
    return { success: false, errors: { root: ["Something went wrong. Try again."] } };
  }
}