"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { updateAttendanceRecord } from "./attendance-actions";
import { formatDuration, STATUS_LABELS, type AttendanceStatus } from "./attendance-helpers";
import type { AttendanceRow } from "./attendance-columns";

// "2:30 PM" -> "14:30", for the time inputs (records display formatted
// labels, but the edit form + server action work with 24h "HH:MM").
function to24Hour(label: string | null): string {
  if (!label) return "";
  const match = label.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (!match) return "";
  let h = Number(match[1]);
  const m = match[2];
  const period = match[3].toUpperCase();
  if (period === "PM" && h !== 12) h += 12;
  if (period === "AM" && h === 12) h = 0;
  return `${String(h).padStart(2, "0")}:${m}`;
}

interface AttendanceEditDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  record: AttendanceRow | null;
}

const STATUS_OPTIONS: AttendanceStatus[] = ["present", "half_day", "absent", "leave"];

export function AttendanceEditDialog({ open, onOpenChange, record }: AttendanceEditDialogProps) {
  const router = useRouter();
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [status, setStatus] = useState<AttendanceStatus>("absent");
  const [errors, setErrors] = useState<Record<string, string[]>>({});
  const [isPending, startTransition] = useTransition();

  useEffect(() => {
    if (record) {
      setCheckIn(to24Hour(record.checkIn));
      setCheckOut(to24Hour(record.checkOut));
      setStatus(record.status);
      setErrors({});
    }
  }, [record, open]);

  function handleSubmit() {
    if (!record) return;
    setErrors({});
    startTransition(async () => {
      const result = await updateAttendanceRecord({
        employeeId: record.employeeId,
        date: record.date,
        checkIn,
        checkOut,
        status,
      });
      if (!result.success) {
        setErrors(result.errors as Record<string, string[]>);
        return;
      }
      toast.success("Attendance updated");
      onOpenChange(false);
      router.refresh();
    });
  }

  if (!record) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Attendance</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <p className="text-xs text-muted-foreground">Employee</p>
              <p className="font-medium">{record.employeeName}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Date</p>
              <p className="font-medium">{record.date}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Designation</p>
              <p className="font-medium">{record.designation}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Hours Worked (current)</p>
              <p className="font-medium">{formatDuration(record.secondsWorked)}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Check In</Label>
              <Input type="time" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} />
              {errors.checkIn && <p className="text-sm text-destructive">{errors.checkIn[0]}</p>}
            </div>
            <div className="space-y-1.5">
              <Label>Check Out</Label>
              <Input type="time" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} />
              {errors.checkOut && <p className="text-sm text-destructive">{errors.checkOut[0]}</p>}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Status</Label>
            <Select value={status} onValueChange={(v: string | null) => setStatus((v ?? "absent") as AttendanceStatus)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map((s) => (
                  <SelectItem key={s} value={s}>
                    {STATUS_LABELS[s]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.status && <p className="text-sm text-destructive">{errors.status[0]}</p>}
          </div>

          <p className="text-xs text-muted-foreground">
            Hours worked are recalculated automatically when both check-in and check-out are set. Leave either
            blank (e.g. for an Absent or Leave day) to clear it.
          </p>

          {errors.root && <p className="text-sm text-destructive">{errors.root[0]}</p>}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isPending}>
            {isPending ? "Saving..." : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
