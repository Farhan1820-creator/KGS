import Link from "next/link";
import { auth } from "@/auth";
import { db } from "@/db";
import { students, fees } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { currentMonth, formatMonthLabel } from "./accounts/fees/fee-range";
import { Badge } from "@/components/ui/badge";
import { Wallet, CheckCircle2 } from "lucide-react";
import { SchoolInfoCard } from "./school-info-card";

type StudentDashboardProps = {
  name?: string | null;
};

const StudentDashboard = async ({ name }: StudentDashboardProps) => {
  const session = await auth();
  const student = session?.user?.id
    ? await db.query.students.findFirst({
        where: eq(students.userId, Number(session.user.id)),
        with: { class: true },
      })
    : null;

  let feeCard = null;

  if (student) {
    const month = currentMonth();
    const feeRow = await db.query.fees.findFirst({
      where: and(eq(fees.studentId, student.id), eq(fees.month, month)),
    });

    feeCard = (
      <div className="rounded-lg border p-4 flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-sm text-muted-foreground">Fee — {formatMonthLabel(month)}</p>
          {student.class && (
            <p className="text-xs text-muted-foreground">
              Class {student.class.name}
              {student.class.section ? ` - ${student.class.section}` : ""}
            </p>
          )}
          {feeRow ? (
            <p className="text-2xl font-semibold">Rs. {feeRow.amount.toLocaleString()}</p>
          ) : (
            <p className="text-sm text-muted-foreground">No fee record for this month yet.</p>
          )}
        </div>
        {feeRow && (
          <Badge
            variant={feeRow.status === "paid" ? "default" : "destructive"}
            className="flex items-center gap-1"
          >
            {feeRow.status === "paid" && <CheckCircle2 className="h-3 w-3" />}
            {feeRow.status === "paid" ? "Paid" : "Unpaid"}
          </Badge>
        )}
      </div>
    );
  }

  return (
    <div className="page-shell space-y-6">
      <div className="text-3xl text-center py-6 w-full flex items-center justify-center">
        <h2>
          Welcome
          <span className="text-primary font-bold">{name ? `, ${name}` : ""}</span>
        </h2>
      </div>

      {feeCard ?? (
        <div className="rounded-lg border border-dashed p-4 text-center text-sm text-muted-foreground">
          <Wallet className="h-4 w-4 mx-auto mb-1" />
          Your student profile isn&apos;t set up yet, so fee details aren&apos;t available.{" "}
          Contact the admin, or see the{" "}
          <Link href="/accounts/fees" className="underline">
            Fees
          </Link>{" "}
          page.
        </div>
      )}

      <SchoolInfoCard />
    </div>
  );
};

export default StudentDashboard;
